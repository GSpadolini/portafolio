-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema twitter
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `twitter` ;

-- -----------------------------------------------------
-- Schema twitter
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `twitter` DEFAULT CHARACTER SET utf8 ;
USE `twitter` ;

-- -----------------------------------------------------
-- Table `twitter`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitter`.`usuario` (
  `idusuario` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(60) NOT NULL,
  `apellido1` VARCHAR(60) NOT NULL,
  `apellido2` VARCHAR(60) NULL,
  `movil` INT NULL,
  `email` VARCHAR(60) NOT NULL,
  `username` VARCHAR(45) NOT NULL,
  `nickusuario` VARCHAR(45) NULL,
  `password` VARCHAR(255) NOT NULL,
  `reg_confirm` TINYINT NOT NULL DEFAULT 0,
  `fecha_alta` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `reg_token` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idusuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `twitter`.`publicacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitter`.`publicacion` (
  `idpublicacion` INT NOT NULL AUTO_INCREMENT,
  `fecha` DATE NOT NULL,
  `twit` VARCHAR(145) NOT NULL,
  `idusuario` INT NOT NULL,
  PRIMARY KEY (`idpublicacion`),
  CONSTRAINT `fk_publicacion_usuario1`
    FOREIGN KEY (`idusuario`)
    REFERENCES `twitter`.`usuario` (`idusuario`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `twitter`.`notificaciones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitter`.`notificaciones` (
  `idnotificaciones` INT NOT NULL AUTO_INCREMENT,
  `mensaje` VARCHAR(45) NULL,
  `idusuario` INT NOT NULL,
  PRIMARY KEY (`idnotificaciones`),
  CONSTRAINT `fk_notificaciones_usuario`
    FOREIGN KEY (`idusuario`)
    REFERENCES `twitter`.`usuario` (`idusuario`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `twitter`.`comentarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitter`.`comentarios` (
  `idcomentarios` INT NOT NULL AUTO_INCREMENT,
  `comentario` VARCHAR(145) NULL,
  `idpublicacion` INT NOT NULL,
  `idusuario` INT NOT NULL,
  PRIMARY KEY (`idcomentarios`),
  CONSTRAINT `fk_comentarios_publicacion1`
    FOREIGN KEY (`idpublicacion`)
    REFERENCES `twitter`.`publicacion` (`idpublicacion`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_comentarios_usuario1`
    FOREIGN KEY (`idusuario`)
    REFERENCES `twitter`.`usuario` (`idusuario`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `twitter`.`retwettear`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitter`.`retwettear` (
  `idretwettear` INT NOT NULL AUTO_INCREMENT,
  `retwettear` VARCHAR(145) NULL,
  `idpublicacion` INT NOT NULL,
  `idusuario` INT NOT NULL,
  PRIMARY KEY (`idretwettear`),
  CONSTRAINT `fk_retwettear_publicacion1`
    FOREIGN KEY (`idpublicacion`)
    REFERENCES `twitter`.`publicacion` (`idpublicacion`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_retwettear_usuario1`
    FOREIGN KEY (`idusuario`)
    REFERENCES `twitter`.`usuario` (`idusuario`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `twitter`.`like`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitter`.`like` (
  `idlike` INT NOT NULL AUTO_INCREMENT,
  `idusuario` INT NOT NULL,
  `idpublicacion` INT NOT NULL,
  PRIMARY KEY (`idlike`),
  CONSTRAINT `fk_like_usuario1`
    FOREIGN KEY (`idusuario`)
    REFERENCES `twitter`.`usuario` (`idusuario`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_like_publicacion1`
    FOREIGN KEY (`idpublicacion`)
    REFERENCES `twitter`.`publicacion` (`idpublicacion`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `twitter`.`follow`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitter`.`follow` (
  `idusuario` INT NOT NULL,
  `idusuario_follow` INT NOT NULL,
  PRIMARY KEY (`idusuario`, `idusuario_follow`),
  CONSTRAINT `fk_follow_usuario1`
    FOREIGN KEY (`idusuario`)
    REFERENCES `twitter`.`usuario` (`idusuario`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_follow_usuario2`
    FOREIGN KEY (`idusuario_follow`)
    REFERENCES `twitter`.`usuario` (`idusuario`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
