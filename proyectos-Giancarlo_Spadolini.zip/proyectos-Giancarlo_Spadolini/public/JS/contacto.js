const inputs = document.querySelectorAll("input");
const spans = document.querySelectorAll("span");
const textarea = document.querySelector("textarea");
const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
const formulario = document.querySelector("#formulario")


inputs[2].addEventListener("click", (e)=>{
  e.preventDefault();
  let cargar = 0;

  for (let i = 0; i < 3; i++) {
    vacio(i);
    if (spans[i].innerHTML === "") {
    cargar ++;
    console.log(cargar);
    }
    
  }

   function vacio(num) {
    if (inputs[num].value === "") {
      spans[num].textContent = "No puede estar vacio";
      spans[num].classList.add("error");
    } else{
      spans[num].textContent = "";
      spans[num].classList.remove("error");
    }
    if (textarea.value.length === 0) {
      spans[2].textContent = "No puede estar vacio";
      spans[2].classList.add("error");
    } else {
      spans[2].textContent = "";
      spans[2].classList.remove("error");
    }
  }

  if (!comp_email.test(inputs[1].value) && inputs[1].value !== "") {
    spans[1].textContent = "No tiene el formato correcto";
    spans[1].classList.add("error");
    cargar--;
  } else if (comp_email.test(inputs[1].value) && inputs[1].value !== ""){
    spans[1].textContent = "";
    spans[1].classList.remove("error");
    cargar++;
  }
  

  if (cargar >= 4) {
    console.log(window.location.href);

    
    const formData1 = new FormData(formulario);
    let reqData1 = {};
    formData1.forEach((value, key) =>{
      reqData1[key] = value;
    });
    
    fetch('/registro/contactoSend',{
      method: 'POST',
      body: JSON.stringify(reqData1),
      headers: { 'Content-Type': 'application/json' },
    })

    .then(response => response.json())
    .then(message => {
      document.querySelector('.response').textContent = message;
    })
    .catch(error => console.log(error))
  }
  
});