const textarea = document.querySelector('textarea');
const twittear = document.querySelector('#twittear');
const formulario = document.querySelector('form')

textarea.addEventListener('keydown', autosize);
             
function autosize(){
  var el = this;
  setTimeout(function(){
    el.style.cssText = 'height:auto; padding:0';
    el.style.cssText = 'height:' + el.scrollHeight + 'px';
  },0);
}

textarea.addEventListener('keyup',()=>{
  if (textarea.value.length === 0) {
    twittear.disabled = true;
    twittear.classList.remove('manito');
  }else{
    twittear.disabled = false;
    twittear.classList.add('manito');
  }
});


twittear.addEventListener('click', ()=>{
   const formData = new FormData(formulario);
    // envio de los datos (JSON) al server mediante petición asíncrona "fetch"
    let reqData = {};
    // rellena un objeto con los datos del form
    formData.forEach((value, key) => reqData[key] = value);
    fetch('twitter/add', {
      method: 'POST',
      body: JSON.stringify(reqData),
      headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(message => {
      alert(message);
      location.reload();
    })
    .catch(error => console.log(error))
});

