const inputs = document.querySelectorAll("input");
const spans = document.querySelectorAll("span");
const formulario = document.querySelector("form")
const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
const comp_contra = /^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$/;

inputs[8].addEventListener("click", (e) => {
  e.preventDefault();
  let enviar = 0;
  /*Comprovamos si los inputs estan vacio */
  function vacio(numero) {
    if (inputs[numero].value.length === 0) {
      spans[numero].textContent = "Este campo no puede estar vacio";
    } else {
      spans[numero].textContent = "";
    }
  }
  //Llamada a la funcion para comprobar que no estan vacios
   for (let i = 0; i < inputs.length-1; i++) {
     if (inputs[2].value === "") {
      spans[2].textContent = "";
     }
     vacio(i);
     if (inputs[7].value === "") {
      inputs[7].value = inputs[0].value;
     }
  }

  if (!comp_email.test(inputs[3].value) && inputs[3].value.length !== 0) {
    spans[3].textContent = "El email no tiene un formato valido";
  }

  if (!comp_contra.test(inputs[4].value) && inputs[4].value.length !== 0) {
    spans[4].textContent = "La contraseña no tiene un formato valido";
  }

  if (inputs[4].value !== inputs[5].value && inputs[5].value.length !== 0) {
    spans[5].textContent = "Las contraseñas no coinciden";
  }

  spans.forEach(element => {
    if (element.innerHTML.length === 0) {
      enviar ++;
      console.log(enviar);
    }
    
  });
 
  if (enviar === 8) {

    const formData = new FormData(formulario);
    let reqData = {};
    // rellena un objeto con los datos del form
    formData.forEach((value, key) => reqData[key] = value);
    // envio de los datos (JSON) al server mediante petición asíncrona "fetch"
    fetch('/registro/formulario', {
      method: 'POST',
      body: JSON.stringify(reqData),
      headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(message => {
      alert(message);
    })
    .catch(error => console.log(error))

  }

})