const buscar = document.querySelector('#buscarBtn');
const formulario = document.querySelector('form');
const perfil = document.querySelector(".buscarUser");
const perfilDiv = document.querySelector('#perfil');
const input = document.querySelector('#buscar');
const username = document.querySelector('#username');
const nickusuario = document.querySelector('#nickusuario');
const follow = document.querySelector('#follow')


buscar.addEventListener("click", (e) => {
  const formData = new FormData(formulario);
  // envio de los datos (JSON) al server mediante petición asíncrona "fetch"
  let reqData = {};
  // rellena un objeto con los datos del form
  formData.forEach((value, key) => reqData[key] = value);
  fetch('twitter/buscar', {
    method: 'POST',
    body: JSON.stringify(reqData),
    headers: { 'Content-Type': 'application/json' }
  })
    .then(response => response.json())
    .then(message => {
      perfil.textContent = message.message;
      username.textContent = message.username;
      nickusuario.textContent = message.nickname;

    })
    .catch(error => console.log(error)) 
    console.log(input.value);
    setTimeout(() => {
      if (perfil.textContent === `Si se encontró ${input.value}`) {
        perfilDiv.classList.remove('invisible');
        perfilDiv.classList.add('visible');
      } else {
        perfilDiv.classList.remove('visible');
        perfilDiv.classList.add('invisible');
      }
    }, 500);
});

follow.addEventListener("click", (e) => {

  const formData = new FormData(formulario);
  // envio de los datos (JSON) al server mediante petición asíncrona "fetch"
  let reqData = {};
  // rellena un objeto con los datos del form
  formData.forEach((value, key) => reqData[key] = value);
  fetch('twitter/follow', {
    method: 'POST',
    body: JSON.stringify(reqData),
    headers: { 'Content-Type': 'application/json' }
  })
    .then(response => response.json())
    .then(message => {
      alert(message.message);
    })
    .catch(error => console.log(error))

});