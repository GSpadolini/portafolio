const inputs = document.querySelectorAll("input");
const spans = document.querySelectorAll("span");
const formulario = document.querySelector("form");
const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
const comp_contra = /^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$/;


inputs[2].addEventListener("click", (e) => {
  e.preventDefault();
  let cargar = 0;

  for (let i = 0; i < 2; i++) {
    vacio(i);
    if (spans[i].innerHTML === "") {
      cargar++;
      // console.log(cargar);
    }

  }

  function vacio(num) {
    if (inputs[num].value === "") {
      spans[num].textContent = "No puede estar vacio";
      spans[num].classList.add("error");
    } else {
      spans[num].textContent = "";
      spans[num].classList.remove("error");
    }
  }

  if (!comp_email.test(inputs[0].value) && (inputs[0].value.length > 0)) {
    spans[0].textContent = "No tiene el formato de email";
    spans[0].classList.add("error");
  } else if (comp_email.test(inputs[0].value) && (inputs[0].value.length > 0)) {
    spans[0].textContent = "";
    spans[0].classList.remove("error");
  }

  if (!comp_contra.test(inputs[1].value) && (inputs[1].value.length > 0)) {
    spans[1].textContent = "No tiene el formato de email";
    spans[1].classList.add("error");
  } else if (comp_contra.test(inputs[1].value) && (inputs[1].value.length > 0)) {
    spans[1].textContent = "";
    spans[1].classList.remove("error");
  }

  /*else  if (!(!comp_email.test(inputs[0].value) && (inputs[0].value.length > 0))) {
    spans[0].textContent = "";
      spans[0].classList.remove("error");
  } 
 */

  if (cargar === 2) {

  const formData = new FormData(formulario);
  let reqData = {};
  // rellena un objeto con los datos del form
  formData.forEach((value, key) => reqData[key] = value);
  // envio de los datos (JSON) al server mediante petición asíncrona "fetch"
  fetch('inicioSesion', {
    method: 'POST',
    body: JSON.stringify(reqData),
    headers: { 'Content-Type': 'application/json' }
  })
    .then(response => response.json())
    .then(message => {
      alert(message);
      if (message === 'Datos de entrada correctos!') {
        location.href = '/twitter';
      }
    })
    .catch(error => console.log(error))
}
  
});