const inputs = document.querySelectorAll("input");
const spans = document.querySelectorAll("span");
const formularioContrasenna = document.querySelector("form");
const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;


inputs[1].addEventListener("click", (e)=>{
  e.preventDefault();
  let cargar = 0;

    if (!comp_email.test(inputs[0].value)) {
      spans[0].textContent = "No tiene el formato de email";
      spans[0].classList.add("error");
    } else{
      spans[0].textContent = "";
      spans[0].classList.remove("error");
      cargar++;
    }

    if (cargar === 1) {

      const formData = new FormData(formularioContrasenna);
      let reqData = {};
      // rellena un objeto con los datos del form
      formData.forEach((value, key) => reqData[key] = value);
      // envio de los datos (JSON) al server mediante petición asíncrona "fetch"
      fetch('forgotPass', {
        method: 'POST',
        body: JSON.stringify(reqData),
        headers: { 'Content-Type': 'application/json' }
      })
      .then(response => response.json())
      .then(message => {
        alert(message);
      })
      .catch(error => console.log(error))
  
    }
  
});