import { Router } from 'express';

const router = Router();

import nodemailer from 'nodemailer';


router.post('/registro/contactoSend', (req,res) => {
  const nombre = req.body.nombre;
  const mensaje = req.body.mensaje;
  const email = req.body.email;
  const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;

  if (nombre.lengh === 0) {
    res.json('Rellena el campo nombre');
  }else if(mensaje.lengh === 0){
    res.json('Rellena el campo mensaje');
  }else if(email.lengh === 0){
    res.json('Rellena el campo email');
  }else if(!comp_email.test(email)){
    res.json('Campo email con formato incorrecto');
  }else{
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth:{
        user: 'netmind22@gmail.com',
        pass: '22netmind'
      }
    })

    const mailOptions = {
      from: 'netmind22@gmail.com',
      to: 'netmind22@gmail.com',
      subject: 'Email enviado con Node',
      html: `
            <div>
            <h1>Datos de Formulario de contacto</h1>
            <h2>Nombre: ${nombre}</h2>
            <h2>Email: ${email}</h2>
            <h2>Mensaje: ${mensaje}</h2>
      `
    }
  
    transporter.sendMail(mailOptions, (err, info) =>{
      if(err) {
        return res.json('Error al enviar los datos!' + err)
      }
      return res.json('Mensaje enviado con éxito!' + info.response)
    })
  }

  // res.json('Usuario registrado correctamente!');
});

export default router;