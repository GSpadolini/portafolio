import { Router } from 'express';
import { hashSync, compareSync } from 'bcrypt';
import nodemailer from 'nodemailer';
import generator from 'generate-password';
import conn from '../database/conn.js';

const router = Router();



router.post('/registro/formulario', (req, res) => {

  const nombre = req.body.nombre;
  const apellido = req.body.apellido1;
  const apellido2 = req.body.apellido2;
  const pass = req.body.pass;
  const pass1 = req.body.pass1;
  const email = req.body.email;
  const username = req.body.username;
  const nickname = req.body.nickname;
  const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
  const comp_contra = /^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$/;

  if (nombre.length === 0) {
    res.json('Rellena el campo nombre');
  } else if (apellido.length === 0) {
    res.json('Rellena el campo apellido');
  } else if (username.length === 0) {
    res.json('Rellena el campo username');
  } else if (nickname.length === 0) {
    res.json('Rellena el campo nickname');
  } else if (pass.length === 0) {
    res.json('Rellena el campo contraseña');
  } else if (!comp_contra.test(pass)) {
    res.json('Campo contraseña con formato incorrecto');
  } else if (email.length === 0) {
    res.json('Rellena el campo email');
  } else if (!comp_email.test(email)) {
    res.json('Campo email con formato incorrecto');
  } else {

    // registro de los datos a DB
    const sql = 'select * from usuario where email = ?'
    conn.query(sql, [email], (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        res.json('El email introducido ya esta registrado')
      } else {

        const hashPass = hashSync(pass, 10);
        const reg_token = generator.generate({
          length: 100,
          numbers: true,
        });

        // url token
        const url_host = `${req.protocol}://${req.get('host')}`;
        const url_link = `${url_host}/reg_confirm?email=${email}&token=${reg_token}`;

        // enviamos email con link de confirmación de registro
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: {
            user: 'netmind22@gmail.com',
            pass: '22netmind'
          }
        });

        const mailOptions = {
          from: 'netmind22@gmail.com',
          to: email,
          subject: 'Confirmación de registro',
          html: ` 
             <div> 
              <h1>Confirmación de registro</h1>
              <h2>Click <a href="${url_link}">aquí</a> para confirmar el registro</h2> 
             </div> 
         `
        }

        transporter.sendMail(mailOptions, (err, info) => {
          if (err) {
            res.json('Error al enviar los datos por email! ' + err);
          }
          const sql = 'insert into usuario values (?,?,?,?,?,?,?,?,?,default,default,?)';
          conn.query(sql, [null, nombre, apellido, apellido2, null, email, username, nickname, hashPass, reg_token], (err, result) => {
            if (err) throw err;
            res.json('Usuario registrado correctamente');
          });
        });


      }
    });
    // res.json('Usuario registrado correctamente!');
  }

});

// Confirmación de registro
router.get('/reg_confirm', (req, res) => {
  const email = req.query.email; // recogemos el email por url proveniente del link de confirmación de registro
  const token = req.query.token; // recogemos el token por url proveniente del link de confirmación de registronom
  // comprobar que el token es el mismo del usuario que tiene en la DB 
  const sql = 'select reg_token from usuario where email = ?';
  conn.query(sql, [email], (err, result) => {
    if (err) throw err; // lanza excepción error
    if (result[0].reg_token === token) {
      const sql = 'update usuario set reg_confirm = 1 where email = ?';
      conn.query(sql, [email], (err, result) => {
        if (err) throw err; // lanza excepción error
        const url_host = `${req.protocol}://${req.get('host')}`;
        const url_link = `${url_host}/inicio_sesion`;
        res.send(`<h3>Registro confirmado correctamente!</h3><a href="${url_link}">Volver</a>`);
      });
    } else {
      res.send(`<h3>Ha ocurrido un error con la confirmación del registro!</h3><a href="${url_link}">Volver</a>`);
    }
  });
  // actualizar el campo (BOOLEAN) de la DB que confirma el registro por email
});

// Recuperación de la contrasenna
router.post('/forgotPass', (req, res) => {

  const forgotPassEmail = req.body.forgotPassEmail;
  const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;

  if (!comp_email.test(forgotPassEmail)) {
    res.json('Campo email con formato incorrecto');
  } else {
    // comprobamos que el email esta registrado en nuestra base de datos
    const sql = 'select * from usuario where email = ?'
    conn.query(sql, [forgotPassEmail], (err, result) => {
      if (err) throw err;
      if (result.lengh === 0) {
        res.json('El email introducido no esta registrado en nuestra app')
      } else {
        const newPassword = generator.generate({
          length: 9,
          numbers: true,
          lowercase: true,
          uppercase: true,
          strict: true
        });
        // enviamos email con nuevo password
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: {
            user: 'netmind22@gmail.com',
            pass: '22netmind'
          }
        });
        const mailOptions = {
          from: 'netmind22@gmail.com',
          to: forgotPassEmail,
          subject: 'Recuperación de contraseña',
          html: ` 
         <div> 
          <h1>Nueva contraseña</h1>
          <h2>Contraseña: ${newPassword}</h2> 
         </div> 
        `
        }

        transporter.sendMail(mailOptions, (err, info) => {
          if (err) {
            res.json('Error al enviar los datos! ' + err);
          }
          const hashNewPass = hashSync(newPassword, 10);
          const sql = 'update usuario set password = ? where email = ?';
          conn.query(sql, [hashNewPass, forgotPassEmail], (err, result) => {
            if (err) throw err; // lanza excepción error
            res.json('Le hemos enviado su nueva contraseña a su correo electrónico');
          });
        });

      }
    });

  }


});

// Inicio Sesion
router.post('/inicioSesion', (req, res) => {

  const signInEmail = req.body.signInEmail;
  const signInPass = req.body.signInPass;
  // 1- validar datos 
  const email_regexp = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;

  if (signInEmail.length === 0) {
    res.json('Rellena el campo email');
  } else if (!email_regexp.test(signInEmail)) {
    res.json('Campo email con formato incorrecto');
  } else { // email validado correctamente
    const sql = "select * from usuario where email = ?";
    conn.query(sql, [signInEmail], (err, result) => {
      if (err) throw err; // lanza excepción error
      if (result.length === 0) { // email no registrado
        res.json('Este email no esta registrado!');
      } else {
        const sql = "select * from usuario where email = ? and reg_confirm = ?";
        conn.query(sql, [signInEmail, true], (err, result) => {
          if (err) throw err; // lanza excepción error
          if (result.length === 0) { // registro no confirmado
            res.json('Registro no confirmado, revise su correo electrónico!');
          } else {
            const hashPassword = result[0].password;
            const comparePasswords = compareSync(signInPass, hashPassword);
            if (comparePasswords) { // password ok -> LOGIN CORRECTO!!!
              // iniciamos sesion
              req.session.idUser = result[0].idusuario;
              req.session.userName = result[0].nombre;
              req.session.userEmail = result[0].email;
              // establecer la duracion de la cookie
              req.session.cookie.maxAge = 1 * 24 * 60 * 60 * 1000// 1 dia (1d/24h/60m/60s/1000ms)
              res.json('Datos de entrada correctos!');
            } else {
              res.json('Contraseña incorrecta!');
            }
          }
        });
      }

    });
  }

});

// Cerrar Sesion
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

export default router;