import { Router, text } from 'express';
import conn from '../database/conn.js';

const router = Router();

import { dateTimeConverter } from '../utils/dateTimeConverter.js';

// añadir twitt
router.post('/twitter/add', (req, res) => {
  const textoT = req.body.texto;
  //const projectImage = req.files.addProjectImage; // recogemos el archivo
  //const projectDescription = req.body.addProjectDescription;
  if (textoT.length === 0 || textoT.length > 140) {
    res.json('Añàde texto para twittear!');
  } else { 
    const fecha_creacion = dateTimeConverter(new Date());
    const sql = 'insert into publicacion values (?,?,?,?)';
    conn.query(sql, [null, fecha_creacion, textoT, req.session.idUser], (err, result) => {
      if (err) throw err; // lanza excepción error
      res.json( `Has tuiteado`); 
    });
 }
 
});


export default router;