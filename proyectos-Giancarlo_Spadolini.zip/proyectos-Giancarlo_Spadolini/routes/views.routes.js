import { Router } from 'express';

const router = Router();

import conn from '../database/conn.js';

router.get('/', (req, res) => {
  res.render('index');
  idUser: res.locals.idUser
});

router.get('/registro', (req, res) => {
  res.render('registro');
  idUser: res.locals.idUser
});

router.get('/inicio_sesion', (req, res) => {
  res.render('inicio_sesion');
  idUser: res.locals.idUser
});

router.get('/contacto', (req, res) => {
  res.render('contacto');
  idUser: res.locals.idUser
});

router.get('/twitter', (req, res) => {
  if (req.session.idUser) { // si existe sesión

    const sql = 'select P.idpublicacion, P.fecha, P.twit, P.idusuario, U.username, U.nickusuario from publicacion P inner join usuario U on U.idusuario=P.idusuario left join follow F on F.idusuario=P.idusuario where U.idusuario = ? or F.idusuario_follow = ? order by P.idpublicacion asc';
    conn.query(sql, [req.session.idUser, req.session.idUser], (err, result) => {
      if (err) throw err; // lanza excepción error
  
      res.render('twitter', {
        idUser: res.locals.idUser,
        userName: res.locals.userName,
        twitts: result
      });
    });
    
  } else {
    res.redirect('inicio_sesion');
  }
});

router.get('/politicas', (req, res) => {
  res.render('politicas');
});

router.get('/buscar', (req, res) => {
  if (req.session.idUser) { // si existe sesión
    const sql = 'select email from usuario where email = ?';
    conn.query(sql, [req.session.idUser], (err, result) => {
      if (err) throw err; // lanza excepción error
      res.render('buscar', {
        idUser: res.locals.idUser
      });
    });
    
    
  } else {
    res.redirect('inicio_sesion');
  }
});

router.get('/forgotPass', (req, res) => {
  res.render('forgotPass');
});

export default router;