import { Router, text } from 'express';
import conn from '../database/conn.js';

const router = Router();

// import { dateTimeConverter } from '../utils/dateTimeConverter.js';

// añadir twitt
router.post('/twitter/buscar', (req, res) => {
  const buscar = req.body.buscar;
  //const projectImage = req.files.addProjectImage; // recogemos el archivo
  //const projectDescription = req.body.addProjectDescription;
  if (buscar.length === 0) {
    res.json('Añàde texto para twittear!');
  } else {
    // const fecha_creacion = dateTimeConverter(new Date());
    const sql = 'select * from usuario where email = (?)';
    conn.query(sql, [buscar], (err, result) => {
      if (err) throw err; // lanza excepción error
      if (result.length === 0) {
        res.json({
          message: "No se ha encontrado coincidencia con el email introducido",
          user: null
        });
      } else {
        res.json({
          user: result,
          message: `Si se encontró ${result[0].email}`,
          nickname: `${result[0].nickusuario}`,
          username: `${result[0].username}`
          // preguntar a Armando como puedo hacer para ver el username message: ${user[0].username}
        });
      }

    });
  }

});

router.post('/twitter/follow', (req, res) => {
  const buscar = req.body.buscar;


  const sql = 'select idusuario from usuario where email = (?)';
  conn.query(sql, [buscar], (err, result) => {
    if (err) throw err; // lanza excepción error
    const idusuario_follow = result[0].idusuario;
    const idusuario = req.session.idUser;
    const sql = 'insert into follow values (?,?)';
    conn.query(sql, [idusuario_follow, idusuario], (err, result) => {
      res.json({
        message: `Estas siguiendo a ${buscar}`
      });
    });
  });


});

export default router;