import { Router } from 'express';
import { hashSync, compareSync} from 'bcrypt';
import conn from '../database/conn.js';

const router = Router();



router.post('forgotPass', (req,res) => {

  const email = req.body.forgotPassEmail;
  const comp_email = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;

if(!comp_email.test(email)){
    res.json('Campo email con formato incorrecto');
  }else{

    // registro de los datos a DB
    const sql = 'select * from usuario where email = ?'
    conn.query(sql, [email], (err, result) =>{
      if(err) throw err;
      if(result.lengh = 0) {
        res.json('El email introducido no esta registrado')
      } else {
        const hashPass = hashSync(pass, 10);
        const sql = 'insert into usuario values (?,?,?,?,?,?,?,?,?)';
        conn.query(sql, [null, nombre, apellido, apellido2, null, email, username, nickname, hashPass], (err, result) =>{
          if(err) throw err;
          res.json('Usuario registrado correctamente');
        });
      }
    })
    // res.json('Usuario registrado correctamente!');
  }

  
});

export default router;